// signup.model.ts
export interface UserModel {
    username: string;
    firstName: string;
    lastName: string;
    userEmail: string;
    address: string;
    password: string;
    phoneNumber: string;
}
