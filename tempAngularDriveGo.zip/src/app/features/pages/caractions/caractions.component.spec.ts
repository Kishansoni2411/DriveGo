// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { CarActionsComponent } from './caractions.component';

// describe('CaractionsComponent', () => {
//   let component: CarActionsComponent;
//   let fixture: ComponentFixture<CarActionsComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       imports: [CaractionsComponent]
//     })
//     .compileComponents();
    
//     fixture = TestBed.createComponent(CaractionsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
