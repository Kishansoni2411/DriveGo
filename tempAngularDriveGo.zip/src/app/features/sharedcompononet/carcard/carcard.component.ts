import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

interface Car {
  company: string;
  model: string;
  year: number;
  color: string;
  price: number;
  mileage: number;
  description: string;
  imageUrl: string;
  status: string;
  carId: number;
}

@Component({
  selector: 'app-carcard',
  standalone: true,
  imports: [CommonModule , BrowserModule ],
  templateUrl: './carcard.component.html',
  styleUrls: ['./carcard.component.css']
})
export class CarCardComponent {
  @Input() car!: Car;
  @Output() edit = new EventEmitter<Car>();
  @Output() delete = new EventEmitter<number>();

  onEdit() {
    this.edit.emit(this.car);
  }

  onDelete() {
    this.delete.emit(this.car.carId);
  }
}









